const {
  exchangeCodeForToken,
  refreshToken
} = require('./tokenAuth.js');

export const handler = async(event) => {
  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        'error': e.toString()
      })
    };
  }

  let result;
  switch (body.action) {
    case 'code':
      result = await exchangeCodeForToken(event.body);
      break;
    case 'refresh':
      result = await refreshToken(event.body);
      break;
    default:
      return {
        statusCode: 400,
        body: JSON.stringify({
          'error': `'${body.action}' is not valid`
        })
      };
  }

  const response = {
      statusCode: 200,
      body: JSON.stringify(result),
  };
  return response;
};